function toggleMenu() {
    const menumobile = document.getElementById('menu');
    const menubutton = document.querySelector('.menubutton');

    if (menumobile.classList.contains('visible')) {
        menumobile.classList.remove('visible');
        menubutton.classList.remove('active');
    } else {
        menumobile.classList.add('visible');
        menubutton.classList.add('active');
    }
}

// Move the toggleSubMenu function outside of toggleMenu
function toggleSubMenu() {
    var submenu = document.getElementById('subMenu');
    if (submenu.classList.contains('hidden')) {
        submenu.classList.remove('hidden');
        submenu.classList.add('visible');
    } else {
        submenu.classList.remove('visible');
        submenu.classList.add('hidden');
    }
}
function toggleSearch() {
    const searchBarContainer = document.getElementById('searchBarContainer');
    const navItems = document.querySelector('.navitems');

    if (searchBarContainer.classList.contains('hidden')) {
        searchBarContainer.classList.remove('hidden');
        navItems.classList.add('hidden');
    } else {
        searchBarContainer.classList.add('hidden');
        navItems.classList.remove('hidden');
    }
}

function toggleCategories() {
    const categoryMenu = document.getElementById('categoryMenu');
    
    if (categoryMenu.classList.contains('hidden')) {
        categoryMenu.classList.remove('hidden');
        categoryMenu.classList.add('visible');
    } else {
        categoryMenu.classList.remove('visible');
        categoryMenu.classList.add('hidden');
    }
}

function toggleCategories() {
    const categoryMenu = document.getElementById('categoryMenu');
    const categoryLink = document.querySelector('.categorylink');
    
    if (categoryMenu.classList.contains('hidden')) {
        categoryMenu.classList.remove('hidden');
        categoryMenu.classList.add('visible');
        categoryLink.classList.add('active');  // Add active state to "Categories"
    } else {
        categoryMenu.classList.remove('visible');
        categoryMenu.classList.add('hidden');
        categoryLink.classList.remove('active');  // Remove active state from "Categories"
    }
}
function toggleCategories() {
    const categoryMenu = document.getElementById('categoryMenu');
    const categoryLink = document.querySelector('.categorylink');
    
    if (categoryMenu.classList.contains('hidden')) {
        categoryMenu.classList.remove('hidden');
        categoryMenu.classList.add('visible');
        categoryLink.classList.add('active');  // Add active state to "Categories"
        
        // Add event listener to detect clicks outside of the menu
        document.addEventListener('click', closeMenuOnClickOutside);
    } else {
        categoryMenu.classList.remove('visible');
        categoryMenu.classList.add('hidden');
        categoryLink.classList.remove('active');  // Remove active state from "Categories"
        
        // Remove event listener when the menu is hidden
        document.removeEventListener('click', closeMenuOnClickOutside);
    }
}

function closeMenuOnClickOutside(event) {
    const categoryMenu = document.getElementById('categoryMenu');
    const categoryLink = document.querySelector('.categorylink');
    
    // Check if the clicked element is outside the menu or the categories link
    if (!categoryMenu.contains(event.target) && !categoryLink.contains(event.target)) {
        categoryMenu.classList.remove('visible');
        categoryMenu.classList.add('hidden');
        categoryLink.classList.remove('active');
        
        // Remove event listener after closing the menu
        document.removeEventListener('click', closeMenuOnClickOutside);
    }
}

