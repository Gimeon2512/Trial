const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

const USERS_FILE = 'users.json';

// Load users from file
function loadUsers() {
    if (fs.existsSync(USERS_FILE)) {
        const data = fs.readFileSync(USERS_FILE);
        return JSON.parse(data);
    }
    return {};
}

// Save users to file
function saveUsers(users) {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

// Create Account
app.post('/create-account', (req, res) => {
    const { username, password, fullName } = req.body;
    const users = loadUsers();

    if (users[username]) {
        return res.status(400).json({ message: 'Username already exists.' });
    }

    users[username] = { password, fullName, profilePicture: null };
    saveUsers(users);
    res.status(201).json({ message: 'Account created successfully.' });
});

// Login
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const users = loadUsers();

    if (users[username] && users[username].password === password) {
        res.json({ message: 'Login successful', user: users[username] });
    } else {
        res.status(401).json({ message: 'Invalid credentials.' });
    }
});

// Update Profile Picture
app.post('/update-profile-picture', (req, res) => {
    const { username, profilePicture } = req.body;
    const users = loadUsers();

    if (users[username]) {
        users[username].profilePicture = profilePicture;
        saveUsers(users);
        res.json({ message: 'Profile picture updated successfully.' });
    } else {
        res.status(404).json({ message: 'User  not found.' });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});